------------------------------
NAME - ATHARVA PALIWAL
ROLL NO .- 40
SUB - COMPUTER NETWORKS
----------------------------
Steps to run the program :
Step 1 : run the cn_assg2.java in one terminal.
Step 2 : run the user1.java in indivisual terminal. 
Step 3 : run the user2.java in indivisual terminal. 
Step 4 : run the user3.java in indivisual terminal. 

Client having Maximum Id will be elected as a leader.Then data of all remaining peers will be received by leader.