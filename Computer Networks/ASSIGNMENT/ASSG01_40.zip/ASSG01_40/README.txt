
-------------------------------------------------------------------------------------

NAME    : ATHARVA PALIWAL
ROLL NO : 40
SUBJECT : COMPUTER NETWORKS
TOPIC   : ASSIGNMENT - 1

-------------------------------------------------------------------------------------

Software application used : NetBeans IDE 8.0.1

Follow the following steps to run the project in NetBeans

 1. Create a new project with name "Assignment_01" 
 2. Copy paste the code form the Assignment_01.java file and paste it in the editor under the project created
 3. Run the code.
	To run this program you will need to provide following data  :
	Step 1:It will ask for the length of chip sequence.
	Step 2:You will need to provide chip sequence for each station.
	Step 3:You will have to provide data signal for each station.
	After providing all the above information you will get the data bits for each station.
 4. Observe the output.
---------------------------------------------------------------------------------------------------------


