def parity_check(n,msg): # Function for checking Parity
    k=n-1
    s=0
    l=len(msg)
    while k<l:
        j=n
        while j!=0 and k<l:
            s=s+int(msg[k])  # Adding the bits of required position
            k=k+1
            j=j-1
        k=k+n
    # Returning 1 for odd no. of 1's and returning 0 for even no. of 1's
    return s%2 
msg=input('Enter your Message in Binary: ')
l=len(msg)
rough_ham_code=msg
i,k,l2=0,0,l
while i!= l: # Generating Rough Hamming Code
    if i+1==2**k:
        rough_ham_code=rough_ham_code[:i]+'0'+rough_ham_code[i:]
        l=l+1
        k=k+1
    i=i+1
par_bits=l-l2 # Total parity bits
print('Roung Hamming Code :',rough_ham_code)
print('Number of Parity Bits :',par_bits)
print('We will use even parity.')
hamming_code=rough_ham_code
for i in range(par_bits): # Generating Hamming Code
    n=2**i
    s=parity_check(n,hamming_code)
    if s==1: # Replacing with 1 in odd no. of 1's
        hamming_code=hamming_code[:n-1]+'1'+hamming_code[n:]
print('Hamming Code :',hamming_code)
rec_msg=input('Enter message at recevier side :')
error_bit=0
for i in range(par_bits):
    n=2**i
    # Checking the bits at location of power of 2's
    s=parity_check(n,rec_msg)
    if s==1:
        error_bit=error_bit+n
if error_bit==0:
    print('No Error!')
else:
    print('Error at Position :',error_bit)