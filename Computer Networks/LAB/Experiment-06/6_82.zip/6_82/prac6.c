#include <stdio.h>

void initAdjacencyMatrix(int MX, int g[][MX]);
void dijkstra(int MX, int g[][MX], int a[MX][MX], int dist[MX], int parent[MX], int src);
void addEdge(int MX, int g[][MX], int src, int dest);
void addVal(int MX, int a[][MX], int x, int y, int wt);
void showAdjacencyMatrix(int MX, int g[][MX]);
void showAdjMat(int MX, int a[][MX]);
void initAdjMat(int MX, int a[][MX]);

int main(void) 
{
  int MX, ed, ed1,ed2, wt,src,dst;
  printf("Enter number of vertices: \n");
  scanf("%d",&MX);
  printf("Enter number of edges: \n");
  scanf("%d",&ed);
  int a[MX][MX];
  int g[MX][MX]; 
  int parent[MX], dist[MX], q[MX];

  //Initialize adjacency matrix
  initAdjacencyMatrix(MX,g);
  initAdjMat(MX,a);
  //Initialize Parent and DIst array
  for(int i =0 ; i< MX; i++)
  {
    parent[i]=0;
    dist[i] = 88;
  }
  
  //Setting up adjacent matrix with weight
  for(int i=0; i<ed; i++){
    printf("\nAdd Edge [%d] : ", i);
    scanf("%d %d",&ed1, &ed2);
    addEdge(MX,g,ed1,ed2);
    addEdge(MX,g,ed2,ed1);

    printf("\nVal[%d][%d] : ",ed1,ed2);
    scanf("%d",&wt);

    addVal(MX, a, ed1, ed2, wt);
    addVal(MX, a, ed2, ed1, wt);
  }

  //Dijkstra 
  showAdjacencyMatrix(MX,g);
  printf("\n");
  showAdjMat(MX,a);
  printf("\n\nEnter source node : ");
  scanf("%d", &src);

  for(int i = 0; i < MX; i++)
  {
    q[i] = i;
  }

  printf("\n== VERTICES ==\n");

  for(int i=0; i<MX; i++)
  {
    printf("| %c |\t", q[i] + 65);
  }

  dijkstra(MX,g,a,dist,parent,src);

  printf("\n== DISTANCE OF EVERY NODE FROM SOURCE NODE ==\n");
  for(int i = 0; i<MX; i++)
  {
    printf("| %d |\t",dist[i]);

  }

  printf("\n== SHORTEST PATH FROM SOURCE NODE TO RESPECTIVE NODE ==\n");

  for(int i = 0; i < MX; i++){
    if(i != src){
      printf("\n------------------------------\n");

      printf("\nDistance of node %c = %d", i+65, dist[i]);
      printf("\nPath = %c",i+65);


      int j=i;
      do
      {
        j = parent[j];
        printf("<- %c", j+65);
      }while(j !=src);
    }
  }

  return 0;
}

void initAdjacencyMatrix(int MX, int g[][MX])
{
  int i , j;
  for(i = 0; i < MX; i++)
  {
    for(j = 0 ; j < MX; j++)
    {
      g[i][j]=0;
    }
  }
}

void initAdjMat(int MX, int a[][MX])
{
  int i, j;
  for(i = 0; i < MX; i++)
  {
    for(j = 0; j < MX; j++)
    {
      a[i][j] = 88;
    }
  }
}

//Add Edge
void addEdge(int MX, int g[][MX], int src, int dest)
{
  g[src][dest] = 1;
}

//Add Edge
void addVal(int MX, int a[][MX], int x, int y, int wt)
{
  a[x][y] = wt;
}

void showAdjacencyMatrix(int MX, int g[][MX])
{
  int i , j;
  printf("\nu|v | \tA\tB\tC\tD\tE\tF\tG\tH\n");
  printf("-------------------------------------");
  printf("\nA   | ");
  for(i = 0 ;i < MX; i++)
  {

    for(j = 0; j<MX; j++)
    {
      printf("\t");
      for(j=0;j<MX;j++)
      {
        printf("%d\t", g[i][j]);
      }
      if(i + 1 < MX)
        printf("\n%c   | ",i + 66);
    }

  }
}

void showAdjMat(int MX, int a[][MX])
{
  int i , j;
  printf("\nu|v | \tA\tB\tC\tD\tE\tF\tG\tH\n");
  printf("-------------------------------------");
  printf("\nA   | ");
  for(i = 0 ;i < MX; i++)
  {

    for(j = 0; j<MX; j++)
    {
      printf("\t");
      for(j=0;j<MX;j++)
      {
        printf("%d\t", a[i][j]);
      }
      if(i + 1 < MX)
        printf("\n%c   | ",i + 66);
    }

  }
}

void dijkstra(int MX, int g[][MX], int a[MX][MX], int dist[MX], int parent[MX], int src)
{
  int visited[MX],count,mindistance, nextnode, i , j;
  for(i = 0; i <MX; i++)
  {
    dist[i]= a[src][i];
    parent[i]= src;
    visited[i] = 0;
  }

  dist[src] = 0;
  visited[src] = 1;
  count = 1;

  while(count < MX-1)
  {
    mindistance = 88;

    for(i = 0; i < MX ; i++)
    {
      if(dist[i] < mindistance && !visited[i])
      {
        mindistance = dist[i];
        nextnode = i;
      }
    }
    visited[nextnode] = 1;
    for(i = 0; i <MX; i++)
    {
      if(!visited[i])
      {
        if(dist[nextnode] + a[nextnode][i] < dist[i])
        {
          dist[i] = dist[nextnode] + a[nextnode][i];
          parent[i] = nextnode;
        }
      }
    }
    count ++ ;
  }
}